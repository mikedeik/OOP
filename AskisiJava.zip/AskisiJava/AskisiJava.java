package AskisiJava;
import Areas.School;
import humans.JuniorStudent;
import humans.SeniorStudent;
import humans.Student;
import humans.Teacher;
import java.util.Random;

public class AskisiJava {

    public static void main(String[] args) {

        int M = args.length;
        if(M != 5){
            System.out.println("Error input!! exiting program...");      // elegxos pws exei dothei swsto plithos orismatwn
        }
        else {
            int[] iargs = new int[M];
            try{
                for (int i = 0; i < M; i++) {
                    iargs[i] = Integer.parseInt(args[i]);               // elegxos gia swsto typo orismatwn
                }
            }
            catch (NumberFormatException ob) {
                System.out.println(ob);
                System.exit(0);
            }
            int Cclass = iargs[0];
            int Lj = iargs[1];
            int Ls = iargs[2];
            int Lt = iargs[3];
            int N = iargs[4];

            int temp = Cclass;
            int ii = 0;
            int temp2 = 1;
            Student[] s = new Student[Cclass * 18];
            Teacher[] t = new Teacher[18];
            School school1 = new School(N, Cclass);

            for (int i = 1; i <= 3; i++) {
                int j = 1;
                while (j <= 6) {
                    while (ii < temp) {
                        if (j <= 3)
                            s[ii] = new JuniorStudent(Lj, i, temp2);                            // Kataskeuazoume tous mathites me th seira analoga me tis aithouses tous
                        else
                            s[ii] = new SeniorStudent(Ls, i, temp2);                            // kai analoga an tha einai Senior h Junior, edw paradexomaste pws oi junior
                        ii++;                                                                   // tha einai stis 3 prwtes takseis tou orofou enw oi senior stis 3 teleutaies

                    }
                    temp += Cclass;
                    j++;
                    temp2++;
                }
            }
            for (int i = 0; i < 18; i++) {                                                        // antistoixa kataskeuazoume tous daskalous
                if (i < 6) t[i] = new Teacher(Lt, 1, i + 1);
                else if (i >= 6 && i < 12) t[i] = new Teacher(Lt, 2, i + 1);
                else t[i] = new Teacher(Lt, 3, i + 1);
            }
            Random r = new Random();

            for (int i = 0; i < Cclass * 18; i++){

                int r2 = r.nextInt(Cclass*18);
                while(s[r2].get_status()){
                    r2 = r.nextInt(Cclass*18);
                }
                school1.enter(s[r2]);
            }

            for (int i = 0; i < 18; i++)
                school1.place(t[i]);

            school1.operate();
            school1.print();
            school1.empty();


        }
    }
}
