package humans;

 abstract public class Student extends Person {

    protected int fl_no;
    protected int cl_no;
    protected boolean is_inside ;


    Student(int rate_of_exhaustion,int fl_no ,int cl_no) {
        super(rate_of_exhaustion);
        this.fl_no = fl_no;
        this.cl_no = cl_no;
        this.is_inside = false;
        System.out.println("A new Student has been created! " + name + " floor no " + fl_no + " class no " + cl_no);
    }

     @Override
     public void print() {
         System.out.print(name);
     }
     @Override
     public int getTiredness(){
         return tiredness;
     }

    public int getFl_no(){
        return fl_no;

    }
    public int getCl_no(){
        return cl_no;
    }
    public void setIs_inside(){
        is_inside = true;
    }
    public void setOutside(){
        is_inside = false;
    }
    public boolean get_status(){
        if(is_inside) return true;
        else return false;
    }
     abstract public void attend();


 }
