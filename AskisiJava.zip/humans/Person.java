package humans;
import java.util.Random;

 abstract public class Person {
    protected String[] names ={ "Mike", "Kwstas", "Panos","Giannis","lampros","Giorgos","Axileas","Periklis","Alexis","Iraklis","Tasos","Pavlo","Dimitris"
            ,"Grigoris","Vaggelis","Alexandros","Manos","Marios","Andreas" ,"Panagiotis","Maria", "Dimitra","Mariana","Giota","Margarita","Iliana ","Efthimia",
            "Alexandra","Lamprini","Roza","Lili","Katia","Asimina","Lia","Aggeliki","Sia","Eva","Erieta","Paraskevi","Xrysa" };

    Random r = new Random();
    protected String name;
    protected int tiredness = 0;
    protected int rate_of_exhaustion;

    public Person(int rate_of_exhaustion){
        name  = names[r.nextInt(40)];
        this.rate_of_exhaustion = rate_of_exhaustion;
    }
    public abstract void print();
    public abstract int getTiredness();
}
