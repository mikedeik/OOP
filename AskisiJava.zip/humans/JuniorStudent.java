package humans;

public final class JuniorStudent extends Student{


    public JuniorStudent(int rate_of_exhaustion,int fl_no,int cl_no){
        super(rate_of_exhaustion,fl_no,cl_no);
    }


    @Override
    public void attend() {
        this.tiredness += rate_of_exhaustion;
    }
}
