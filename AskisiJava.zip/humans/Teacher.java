package humans;

public final class Teacher extends Person{

    private int fl_no;
    private int  cl_no;
    private boolean is_inside;

    public Teacher(int rate_of_exhaustion,int fl_no,int cl_no){
        super(rate_of_exhaustion);
        this.fl_no = fl_no;
        this.cl_no = cl_no;
        is_inside = false;
        System.out.println("A new Teacher has been created! " + name + " floor no " + fl_no + " class no " + cl_no);
    }

    @Override
    public void print() {
        System.out.print(name);
    }

    @Override
    public int getTiredness() {
        return tiredness;
    }

    public int getCl_no() {
        return cl_no;
    }

    public int getFl_no() {
        return fl_no;
    }

    public void set_inside() {
        is_inside = true;
    }
    public void set_outside(){
        is_inside = false;
    }
    public boolean get_status(){
        if(is_inside) return true;
        else return false;
    }
    public void teach(){
        tiredness+= rate_of_exhaustion;
    }
}
