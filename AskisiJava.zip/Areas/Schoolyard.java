package Areas;

import humans.Student;

public final class Schoolyard extends StandingArea{

     public Schoolyard(){

    }

    @Override
    protected void enter(Student s) {
         students[0] = s;
         students[0].print();
         System.out.println(" enters Schoolyard!");

    }

    @Override
    protected Student exit() {
        students[0].print();
        System.out.println(" exits Schoolyard!");
        return students[0];

    }
}
