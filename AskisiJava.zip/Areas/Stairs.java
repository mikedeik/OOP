package Areas;

import humans.Student;

public final class Stairs extends StandingArea{


    @Override
    protected void enter(Student s) {
        students[0] = s;
        students[0].print();
        System.out.println(" enters Stairs!");
    }

    @Override
    protected Student exit() {
        students[0].print();
        System.out.println(" exits Stairs!");
        return students[0];
    }
}
