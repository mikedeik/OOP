package Areas;
import humans.Student;
import humans.Teacher;



public final class School extends OperatingArea{
    private Schoolyard yard;
    private Stairs stairs;
    private Floor[] floors;
    private int Cclass;

    public School(int operating_hours,int Cclass){
        super(operating_hours);
        this.Cclass = Cclass;
        this.yard = new Schoolyard();
        this.stairs = new Stairs();
        this.floors = new Floor[3];
        for (int i=0; i<3; i++)
            floors[i] = new Floor(operating_hours,Cclass,i+1);
        System.out.println("A new School has been created!");
    }
    @Override
    public void enter(Student s){
        students[0] = s;
        students[0].print();
        System.out.println(" enters School!");
        yard.enter(students[0]);

        stairs.enter(yard.exit());
        for(int i = 0; i<3 ; i++){
            if (students[0].getFl_no() == floors[i].getFl_no()) {
                floors[i].enter(stairs.exit());
                students[0] = null;

                break;
            }
        }
    }

    @Override
    public void place(Teacher t) {
        teachers[0] = t;
        for (int i = 0 ; i < 3; i++){
            if (teachers[0].getFl_no() == floors[i].getFl_no()){
                floors[i].place(teachers[0]);
                teachers[0] = null;
                break;
            }
        }

    }

    @Override
    public void operate() {
        for (Floor floor: floors) floor.operate();

    }

    @Override
    public void print() {
        System.out.println("School life consists of :");
        for (Floor floor: floors) floor.print();

    }
    public void empty(){
      for (int i = 0; i< Cclass * 18; i++) {
          for (Floor floor : floors) {
              students[0] = floor.exit();
              if (students[0] != null) {
                  stairs.enter(students[0]);
                  yard.enter(stairs.exit());
                  students[0] = yard.exit();
                  students[0].print();
                  System.out.println(" exits school");
                  students[0] = null;
                  break;
              }

          }
      }

      for (Floor floor : floors) {
              floor.teachers_out();
      }

    }
}
