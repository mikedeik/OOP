package Areas;

import humans.Student;

abstract public class StandingArea {
    protected Student[] students;


    StandingArea(){

        students = new Student[1];

    }
    abstract protected void enter(Student s);
    abstract protected Student exit();

}
