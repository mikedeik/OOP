package Areas;

import humans.Student;
import humans.Teacher;

public final class Classroom extends OperatingArea{
    private int Cclass;
    private int cl_no;
    private Student[] cl_students;


    public Classroom(int operating_hours, int Cclass, int cl_no){
        super(operating_hours);
        this.Cclass = Cclass;
        this.cl_no = cl_no;
        this.cl_students = new Student[Cclass];
        for(Student student: cl_students) student = null;
        System.out.println("A new Classroom has been created!");



    }

    @Override
    public void enter(Student s) {
       for (int i =0; i< Cclass ; i++){
           if (cl_students[i] == null){
               cl_students[i] = s;
               cl_students[i].print();
               System.out.println(" enters Classroom!");
               cl_students[i].setIs_inside();
               break;
           }
       }

    }

    @Override
    public void place(Teacher t) {
        teachers[0] = t;
        teachers[0].set_inside();
        teachers[0].print();
        System.out.println(" got placed " + cl_no);

    }

    @Override
    public void operate() {

        for (Student student: cl_students){
            if(student != null){
                for(int i = 0; i < operating_hours; i++) {
                    student.attend();

                }
            }
        }
        for (int i =0; i< operating_hours; i++)
            teachers[0].teach();




    }

    @Override
    public void print() {
        System.out.println("People in Classroom " + cl_no + " are : ");
        for (Student student: cl_students) {
            if (student.get_status()) {
                student.print();
                System.out.println(" with exhaustion " + student.getTiredness());

            }
        }
        if(teachers[0].get_status()) {
            System.out.println("The Teacher is : ");
            teachers[0].print();
            System.out.println(" with exhaustion " + teachers[0].getTiredness());
        }

    }
    protected int getCl_no(){
        return cl_no;
    }
    protected Student exit(){          // xrhsimopoiwntas to voithiko edw pinaka students epistrefoume ton prwto diathesimo mathiti ths taksis
        for (int i=0; i< Cclass; i++){
            if(cl_students[i].get_status()) {
                students[0] = cl_students[i];
                students[0].print();
                System.out.println(" starts exiting!");
                students[0].print();
                System.out.println(" exits Classroom!");
                break;
            }
        }
        if(students[0] != null) {             // se periptwsh pou exoume ftasei ston teleutaio mathiti
            if (!students[0].get_status())
                students[0] = null;
        }
        if(students[0] != null){              // thetoume to kathe mathiti pou tha epistrafei na einai ektos taksis
            students[0].setOutside();

        }
        return students[0];
    }

    protected void teacher_out(){

        teachers[0].set_outside();
        teachers[0].print();

        System.out.println(" floor no " + teachers[0].getFl_no() + " classroom no " + teachers[0].getCl_no() + " teacher is out!");

    }

}


