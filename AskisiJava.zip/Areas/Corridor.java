package Areas;

import humans.Student;

public final class Corridor extends StandingArea{


    @Override
    protected void enter(Student s) {
        students[0] = s;
        students[0].print();
        System.out.println(" enters Corridor!");
    }

    @Override
    protected Student exit() {
        students[0].print();
        System.out.println(" exits Corridor!");
        return students[0];
    }
}
