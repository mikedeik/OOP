package Areas;
import humans.*;

abstract public class OperatingArea {

    protected Student[] students;
    protected Teacher[] teachers;
    protected int operating_hours;

    protected OperatingArea(int operating_hours){

        this.operating_hours = operating_hours;
        students = new Student[1];
        teachers = new Teacher[1];
        students[0] = null;
        teachers[0] = null;


    }
    abstract public void enter(Student s);    // einai public giati theloume na mporei na thn xrhsimopoihsei h main
    abstract public void place(Teacher t);
    abstract public void operate();
    abstract public void print();

}
