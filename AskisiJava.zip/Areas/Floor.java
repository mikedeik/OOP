package Areas;

import humans.Student;
import humans.Teacher;

public final class Floor extends OperatingArea{
    private int fl_no;
    private int Cclass;
    private Corridor corridor;
    private Classroom[] classrooms;


    public Floor(int operating_hours,int Cclass, int fl_no ){
        super(operating_hours);
        this.Cclass = Cclass;
        this.fl_no = fl_no;
        corridor = new Corridor();
        classrooms = new Classroom[6];
        for (int i = 0; i < 6; i++) {															// O orofos einai ena operating area
            switch (fl_no)
            {
                case(1):
                    classrooms[i] = new Classroom(operating_hours, Cclass,i+1 );					// Analoga me ton arithmo orofou kataskeuazei tis antistoixes takseis
                    break;																			// kai ton antistoixo diadromo
                case(2):
                    classrooms[i] = new Classroom(operating_hours, Cclass, i+7);
                    break;
                case(3):
                    classrooms[i] = new Classroom(operating_hours, Cclass, i+13);
                    break;
            }

        }
        System.out.println("A new Floor has been created!");

    }
    public int getFl_no(){
        return fl_no;
    }

    @Override
    public void enter(Student s) {
        students[0] = s;
        students[0].print();
        System.out.println(" enters Floor!");
        corridor.enter(students[0]);
        for (int i = 0; i < 6; i++) {
            if (classrooms[i].getCl_no() == students[0].getCl_no()) {
                classrooms[i].enter(corridor.exit());
                students[0] = null;
                break;
            }
        }

    }

    @Override
    public void place(Teacher t) {
        teachers[0] = t;
        for(int i = 0; i< 6 ; i++){
            if(classrooms[i].getCl_no() == teachers[0].getCl_no()){
                classrooms[i].place(teachers[0]);
                break;
            }
        }


    }

    @Override
    public void operate() {                  // kalei thn operate twn taksewn
        for(Classroom classroom: classrooms) classroom.operate();

    }

    @Override
    public void print() {
        System.out.println("People in Floor " + fl_no + " are : ");
        for(Classroom classroom: classrooms) classroom.print();

    }
    protected Student exit(){           // protected giati tha th xrhsimpopoihsoun mono oi klaseis tou paketou
        for (Classroom classroom: classrooms) {
            students[0] = classroom.exit();
            if (students[0] != null){
                corridor.enter(students[0]);
                students[0] = corridor.exit();
                if(students[0] != null) {
                    students[0].print();
                    System.out.println(" exits Floor!");
                    break;
                }

            }
        }
        return students[0];

    }

    protected void teachers_out(){                  // protected giati tha thn xrhsimopoihsoun mono oi klaseis tou paketou

        for (Classroom classroom: classrooms)
            classroom.teacher_out();


    }
}
